# corpus-mlx (fixed src layout)

Install MLX separately. Then `pip install -e .` from this repo.
