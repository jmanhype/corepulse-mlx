# API Documentation - Zero-Hallucination Video Processing

## Base URL
```
http://localhost:8000
```

## Endpoints

### POST /process-video
Process a video with zero-hallucination product placement

**Request:**
```bash
curl -X POST "http://localhost:8000/process-video" \
     -F "video=@input_video.mp4" \
     -F "campaign_type=product_hero"
```

**Response:**
```json
{
  "success": true,
  "processing_time": 45.2,
  "output_files": [
    "output/video_name/final_video.mp4",
    "output/video_name/control_schedule.json",
    "output/video_name/tracking_data.json"
  ],
  "quality_metrics": {
    "hallucination_rate": 0.0,
    "temporal_consistency": 0.98,
    "product_preservation": 0.999
  }
}
```

### GET /health
Health check endpoint

**Response:**
```json
{
  "status": "healthy",
  "version": "1.0"
}
```

### GET /status
System status and resource usage

**Response:**
```json
{
  "gpu_available": true,
  "gpu_memory": 48.0,
  "cpu_percent": 25.3,
  "memory_percent": 45.7,
  "disk_usage": 23.1
}
```

## Campaign Types

- `product_hero` - Hero product showcase
- `lifestyle_integration` - Product in lifestyle scenes
- `unboxing_reveal` - Unboxing experience
- `problem_solution` - Problem-solution narrative
- `social_proof` - Customer testimonials

## Error Handling

All errors return appropriate HTTP status codes:
- `400` - Bad request (invalid parameters)
- `500` - Server error (processing failure)
- `200` - Success

Error response format:
```json
{
  "error": "Description of error",
  "details": "Additional error details"
}
```
