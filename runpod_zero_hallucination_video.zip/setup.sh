#!/bin/bash
# RunPod Setup Script for Zero-Hallucination Video Processing

echo "🚀 Setting up Zero-Hallucination Video Processing on RunPod..."

# Create directories
mkdir -p models/
mkdir -p input/
mkdir -p output/
mkdir -p temp/
mkdir -p logs/

# Set up Python path
export PYTHONPATH="/workspace/src:$PYTHONPATH"

# Download required models
echo "📥 Downloading SDXL models..."
cd models/

# SDXL Turbo (for fast generation)
if [ ! -f "sdxl_turbo.safetensors" ]; then
    wget -O sdxl_turbo.safetensors "https://huggingface.co/stabilityai/sdxl-turbo/resolve/main/sd_xl_turbo_1.0_fp16.safetensors"
fi

# VAE
if [ ! -f "sdxl_vae.safetensors" ]; then
    wget -O sdxl_vae.safetensors "https://huggingface.co/madebyollin/sdxl-vae-fp16-fix/resolve/main/sdxl_vae.safetensors"
fi

cd ..

# Clone and setup WAN 2.2 (for depth extraction)
echo "📥 Setting up WAN 2.2..."
if [ ! -d "WAN_2_2" ]; then
    git clone https://github.com/kijai/ComfyUI-WarpFusion WAN_2_2
    cd WAN_2_2
    pip install -r requirements.txt
    cd ..
fi

# Test installation
echo "🧪 Testing installation..."
python -c "import torch; print(f'CUDA available: {torch.cuda.is_available()}')"
python -c "import cv2; print(f'OpenCV version: {cv2.__version__}')"
python -c "from src.corepulse_video_logic import CorePulseVideoLogic; print('✅ Logic modules loaded')"

# Create test video if needed
if [ ! -f "input/test_video.mp4" ]; then
    echo "🎬 Creating test video..."
    python -c "
import cv2
import numpy as np

# Create simple test video
fourcc = cv2.VideoWriter_fourcc(*'mp4v')
out = cv2.VideoWriter('input/test_video.mp4', fourcc, 30.0, (640, 480))

for i in range(90):  # 3 seconds at 30fps
    frame = np.ones((480, 640, 3), dtype=np.uint8) * 240
    # Add moving red circle (product)
    x = 100 + i * 4
    cv2.circle(frame, (x, 240), 30, (255, 0, 0), -1)
    out.write(frame)

out.release()
print('✅ Test video created')
"
fi

echo "✅ RunPod setup complete!"
echo "🎯 Ready for zero-hallucination video processing"
echo ""
echo "Quick start:"
echo "  python runpod_main.py --test                    # Run tests"
echo "  python runpod_main.py --video input/test.mp4    # Process video"
echo "  python runpod_main.py --api                     # Start API server"
